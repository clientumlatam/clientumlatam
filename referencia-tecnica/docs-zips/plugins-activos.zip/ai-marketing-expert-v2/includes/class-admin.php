<?php
/**
 * Admin handler - menus, enqueue, dashboard page.
 *
 * @package WPSpace\AiMarketingExpert
 */

namespace WPSpace\AiMarketingExpert;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	/**
	 * Module Manager.
	 *
	 * @var ModuleManager
	 */
	private ModuleManager $modules;

	/**
	 * Admin page hook suffix.
	 *
	 * @var string
	 */
	private string $hook_suffix = '';

	/**
	 * All hook suffixes for submenu pages.
	 *
	 * @var array
	 */
	private array $hook_suffixes = array();

	/**
	 * Constructor.
	 *
	 * @param ModuleManager $modules Module manager instance.
	 */
	public function __construct( ModuleManager $modules ) {
		$this->modules = $modules;

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'fix_zxcvbn_async' ), 99 );
		add_action( 'admin_init', array( $this, 'activation_redirect' ) );
		add_action( 'admin_init', array( $this, 'redirect_inactive_module_pages' ) );
		add_filter( 'plugin_action_links_' . AIME_PLUGIN_BASENAME, array( $this, 'plugin_action_links' ) );
	}

	/**
	 * Register admin menu and submenu pages.
	 */
	public function register_menu(): void {
		// Main menu page — Dashboard.
		$this->hook_suffix = add_menu_page(
			__( 'AI Marketing Expert', 'ai-marketing-expert' ),
			__( 'AI Marketing', 'ai-marketing-expert' ),
			'manage_options',
			'ai-marketing-expert',
			array( $this, 'render_app' ),
			'dashicons-megaphone',
			2
		);

		$this->hook_suffixes[] = $this->hook_suffix;

		// Dashboard submenu (replaces the auto-generated duplicate).
		$this->hook_suffixes[] = add_submenu_page(
			'ai-marketing-expert',
			__( 'Dashboard', 'ai-marketing-expert' ),
			__( 'Dashboard', 'ai-marketing-expert' ),
			'manage_options',
			'ai-marketing-expert',
			array( $this, 'render_app' )
		);

		$this->register_module_submenus();

		// ── AI Providers submenu ─────────────────────────────────────
		$this->hook_suffixes[] = add_submenu_page(
			'ai-marketing-expert',
			__( 'AI Providers', 'ai-marketing-expert' ),
			__( 'AI Providers', 'ai-marketing-expert' ),
			'manage_options',
			'ai-marketing-expert-ai-providers',
			array( $this, 'render_app' )
		);

		// ── Settings submenu ─────────────────────────────────────────
		$this->hook_suffixes[] = add_submenu_page(
			'ai-marketing-expert',
			__( 'Settings', 'ai-marketing-expert' ),
			__( 'Settings', 'ai-marketing-expert' ),
			'manage_options',
			'ai-marketing-expert-settings',
			array( $this, 'render_app' )
		);

		// ── WhatsApp submenu (plain PHP page — QR pairing lives outside the React bundle) ─
		if ( $this->modules->is_active( 'chatbot' ) ) {
			add_submenu_page(
				'ai-marketing-expert',
				__( 'WhatsApp', 'ai-marketing-expert' ),
				__( 'WhatsApp', 'ai-marketing-expert' ),
				'manage_options',
				'ai-marketing-expert-whatsapp',
				array( $this, 'render_whatsapp_page' )
			);
		}
	}

	/**
	 * Register only active module submenu pages.
	 *
	 * @return void
	 */
	private function register_module_submenus(): void {
		$module_pages = $this->get_module_admin_pages();

		foreach ( $module_pages as $module_id => $page ) {
			if ( ! $this->modules->is_active( $module_id ) ) {
				continue;
			}

			$menu_title = $page['menu_title'];
			if ( 'chatbot' === $module_id ) {
				$active_count = $this->get_active_conversation_count();
				if ( $active_count > 0 ) {
					$menu_title .= sprintf( ' <span class="awaiting-mod">%d</span>', $active_count );
				}
			}

			$this->hook_suffixes[] = add_submenu_page(
				'ai-marketing-expert',
				$page['page_title'],
				$menu_title,
				'manage_options',
				$page['slug'],
				array( $this, 'render_app' )
			);
		}
	}

	/**
	 * Get module admin page metadata keyed by module ID.
	 *
	 * @return array
	 */
	private function get_module_admin_pages(): array {
		return array(
			'email-marketing'   => array(
				'slug'       => 'ai-marketing-expert-email',
				'page_title' => __( 'Email Marketing', 'ai-marketing-expert' ),
				'menu_title' => __( 'Email Marketing', 'ai-marketing-expert' ),
			),
			'seo'               => array(
				'slug'       => 'ai-marketing-expert-seo',
				'page_title' => __( 'SEO Analyzer', 'ai-marketing-expert' ),
				'menu_title' => __( 'SEO Analyzer', 'ai-marketing-expert' ),
			),
			'content-generator' => array(
				'slug'       => 'ai-marketing-expert-content',
				'page_title' => __( 'Content Generator', 'ai-marketing-expert' ),
				'menu_title' => __( 'Content Generator', 'ai-marketing-expert' ),
			),
			'chatbot'           => array(
				'slug'       => 'ai-marketing-expert-chatbot',
				'page_title' => __( 'Chatbot', 'ai-marketing-expert' ),
				'menu_title' => __( 'Chatbot', 'ai-marketing-expert' ),
			),
			'social-media'      => array(
				'slug'       => 'ai-marketing-expert-social',
				'page_title' => __( 'Social Media', 'ai-marketing-expert' ),
				'menu_title' => __( 'Social Media', 'ai-marketing-expert' ),
			),
		);
	}

	/**
	 * Redirect direct access to inactive module pages back to Settings > Modules.
	 *
	 * @return void
	 */
	public function redirect_inactive_module_pages(): void {
		if ( wp_doing_ajax() || ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin page slug used for route guarding; no state change occurs here.
		$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( '' === $current_page ) {
			return;
		}

		foreach ( $this->get_module_admin_pages() as $module_id => $page ) {
			if ( $current_page === $page['slug'] && ! $this->modules->is_active( $module_id ) ) {
				wp_safe_redirect( admin_url( 'admin.php?page=ai-marketing-expert-settings&tab=modules&module_disabled=1' ) );
				exit;
			}
		}
	}

	/**
	 * Enqueue React app and styles.
	 *
	 * @param string $hook_suffix Current page hook suffix.
	 */
	public function enqueue_assets( string $hook_suffix ): void {
		// Only load on our admin pages.
		if ( ! in_array( $hook_suffix, $this->hook_suffixes, true ) ) {
			return;
		}

		$asset_file = AIME_PLUGIN_DIR . 'build/index.asset.php';

		if ( ! file_exists( $asset_file ) ) {
			return;
		}

		$asset = include $asset_file;
		$version = aime_asset_version( $asset['version'] ?? AIME_VERSION );

		// Enqueue React app.
		wp_enqueue_script(
			'aime-dashboard',
			AIME_PLUGIN_URL . 'build/index.js',
			array_merge( $asset['dependencies'], array( 'wp-block-library' ) ),
			$version,
			true
		);

		// Enqueue styles.
		// style-index.css contains vendor CSS (e.g. @xyflow/react) extracted
		// from JS-imported stylesheets – it must be loaded before our own CSS.
		if ( file_exists( AIME_PLUGIN_DIR . 'build/style-index.css' ) ) {
			wp_enqueue_style(
				'aime-dashboard-vendor',
				AIME_PLUGIN_URL . 'build/style-index.css',
				array( 'wp-components' ),
				$version
			);
		}
		if ( file_exists( AIME_PLUGIN_DIR . 'build/index.css' ) ) {
			wp_enqueue_style(
				'aime-dashboard',
				AIME_PLUGIN_URL . 'build/index.css',
				array( 'wp-components', 'aime-dashboard-vendor' ),
				$version
			);
		}

		// Localize script with plugin data.
		wp_localize_script(
			'aime-dashboard',
			'aimeData',
			$this->get_localized_data()
		);

		// WordPress media uploader (for image uploads).
		wp_enqueue_media();

		// ── Gutenberg Block Editor for email composition ─────────────
		// Enqueue core block styles and scripts.
		wp_enqueue_style( 'wp-block-library' );
		wp_enqueue_style( 'wp-block-editor' );
		wp_enqueue_style( 'wp-format-library' );
		wp_enqueue_style( 'wp-components' );
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'wp-editor' );

		// Editor scripts – declared as dependencies in the build asset file
		// but we explicitly enqueue to ensure they load.
		wp_enqueue_script( 'wp-block-editor' );
		wp_enqueue_script( 'wp-block-library' );
		wp_enqueue_script( 'wp-blocks' );
		wp_enqueue_script( 'wp-data' );
		wp_enqueue_script( 'wp-rich-text' );
		wp_enqueue_script( 'wp-format-library' );
		wp_enqueue_script( 'wp-media-utils' );

		// Also keep TinyMCE available for backwards compatibility / HTML mode.
		wp_enqueue_editor();

		// Animate.css (bundled locally for WordPress.org compliance).
		wp_enqueue_style(
			'animate-css',
			AIME_PLUGIN_URL . 'assets/css/animate.min.css',
			array(),
			aime_asset_version( '4.1.1' )
		);
	}

	/**
	 * Replace zxcvbn-async with the synchronous version so the password-strength
	 * library is always available before user-profile.js event handlers fire.
	 * Without this, Firefox throws "can't access property serialize, c is undefined".
	 */
	public function fix_zxcvbn_async(): void {
		wp_dequeue_script( 'zxcvbn-async' );
		wp_enqueue_script( 'zxcvbn' );
	}

	/**
	 * Build block-editor settings (colors, typography, spacing, etc.)
	 * so the standalone Gutenberg editor exposes full inspector panels.
	 *
	 * @return array
	 */
	private function get_block_editor_settings(): array {
		$block_editor_context = new \WP_Block_Editor_Context( array( 'name' => 'core/edit-post' ) );

		// get_block_editor_settings() merges theme.json / global-styles into the result.
		$core = function_exists( 'get_block_editor_settings' )
			? get_block_editor_settings( array(), $block_editor_context )
			: array();

		$experimental = isset( $core['__experimentalFeatures'] ) ? $core['__experimentalFeatures'] : array();

		// Guarantee the essentials exist so BlockInspector shows its panels.
		if ( empty( $experimental ) ) {
			$experimental = array(
				'appearanceTools' => true,
				'color'           => array(
					'background'       => true,
					'text'             => true,
					'defaultPalette'   => true,
					'defaultGradients' => false,
				),
				'typography'      => array(
					'fontSizes'       => array(),
					'lineHeight'      => true,
					'dropCap'         => false,
				),
				'spacing'         => array(
					'padding' => true,
					'margin'  => true,
				),
			);
		}

		// Allowed image sizes for the Media block.
		$image_sizes = array();
		foreach ( get_intermediate_image_sizes() as $size ) {
			$image_sizes[] = array(
				'slug' => $size,
				'name' => $size,
			);
		}

		return array(
			'alignWide'                         => false,
			'allowedMimeTypes'                  => get_allowed_mime_types(),
			'imageSizes'                        => $image_sizes,
			'isRTL'                             => is_rtl(),
			'maxUploadFileSize'                 => wp_max_upload_size(),
			'__experimentalBlockPatterns'       => array(),
			'__experimentalFeatures'            => $experimental,
			'disableCustomColors'               => get_theme_support( 'disable-custom-colors' ) ? true : false,
			'disableCustomFontSizes'            => false,
			'disableCustomGradients'            => true,
			'enableCustomLineHeight'            => true,
			'enableCustomSpacing'               => true,
			'enableCustomUnits'                 => false,
			'keepCaretInsideBlock'              => false,
			'colors'                            => isset( $core['colors'] ) ? $core['colors'] : array(),
			'fontSizes'                         => isset( $core['fontSizes'] ) ? $core['fontSizes'] : array(),
			'gradients'                         => array(),
			'styles'                            => isset( $core['styles'] ) ? $core['styles'] : array(),
		);
	}

	/**
	 * Get the localized data for the React app.
	 *
	 * @return array
	 */
	private function get_localized_data(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin page slug forwarded to the app for UI state; no privileged action is processed.
		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : 'ai-marketing-expert';

		return array(
			'apiUrl'         => rest_url( aime_rest_namespace() ),
			'nonce'          => wp_create_nonce( 'wp_rest' ),
			'adminUrl'       => admin_url(),
			'pluginUrl'      => AIME_PLUGIN_URL,
			'version'        => AIME_VERSION,
			'hasPro'         => aime_has_pro(),
			'modules'        => $this->modules->get_dashboard_configs(),
			'freeLimits'     => aime_free_limits(),
			'siteUrl'        => home_url(),
			'siteName'       => get_bloginfo( 'name' ),
			'adminEmail'     => get_option( 'admin_email' ),
			'currentPage'    => $current_page,
			'hasWooCommerce' => class_exists( 'WooCommerce' ),
			'wpRoles'        => wp_roles()->get_names(),
			'smtpProviders'  => SmtpProvider::get_providers(),
			'aiConfigured'   => ! empty( AiProvider::get_active_model( 'text' )['api_key'] ),
			'blockEditorSettings' => $this->get_block_editor_settings(),
			'currentUser'    => array(
				'id'          => get_current_user_id(),
				'displayName' => wp_get_current_user()->display_name,
				'email'       => wp_get_current_user()->user_email,
			),
			'proUrl'         => apply_filters( 'aime_pro_url', 'https://wpthemespace.com/product/ai-marketing-expert' ),
			'menuSlug'       => 'ai-marketing-expert',
			'isDebug'        => defined( 'WP_DEBUG' ) && WP_DEBUG,
		);
	}

	/**
	 * Render the React app container.
	 */
	public function render_app(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'ai-marketing-expert' ) );
		}

		echo '<div id="aime-app" class="aime-dashboard-wrap"></div>';
	}

	/**
	 * Redirect to dashboard on first activation.
	 */
	public function activation_redirect(): void {
		if ( ! get_transient( 'aime_activation_redirect' ) ) {
			return;
		}

		delete_transient( 'aime_activation_redirect' );

		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Standard WP activation redirect guard; value not used.
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=ai-marketing-expert' ) );
		exit;
	}

	/**
	 * Add action links to plugins page.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( array $links ): array {
		$plugin_links = array(
			'<a href="' . esc_url( admin_url( 'admin.php?page=ai-marketing-expert' ) ) . '">' .
				esc_html__( 'Dashboard', 'ai-marketing-expert' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=ai-marketing-expert-ai-providers' ) ) . '">' .
				esc_html__( 'Settings', 'ai-marketing-expert' ) . '</a>',
		);

		if ( ! aime_has_pro() ) {
			$plugin_links[] = '<a href="' . esc_url( apply_filters( 'aime_pro_url', 'https://wpthemespace.com/product/ai-marketing-expert' ) ) . '" style="color: #FF6B35; font-weight: bold;" target="_blank">' .
				esc_html__( 'Go Pro', 'ai-marketing-expert' ) . '</a>';
		}

		return array_merge( $plugin_links, $links );
	}

	/**
	 * Get count of active / human_takeover chatbot conversations for badge.
	 *
	 * @return int
	 */
	private function get_active_conversation_count(): int {
		global $wpdb;
		$table = $wpdb->prefix . 'aime_chatbot_conversations';

		// Bail if the table doesn't exist yet (before activation).
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
			return 0;
		}

	
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE status IN (%s, %s)',
				$table,
				'active',
				'human_takeover'
			)
		);
	}
	/**
	 * Render the standalone WhatsApp pairing/status admin page.
	 *
	 * Kept as plain PHP (not part of the React build) so it can ship
	 * without touching the compiled JS bundle.
	 */
	public function render_whatsapp_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'ai-marketing-expert' ) );
		}

		global $wpdb;
		$bots = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}aime_chatbot_bots WHERE status = 'active' ORDER BY name ASC" );

		$rest_url = esc_url_raw( rest_url( aime_rest_namespace() . '/chatbot/whatsapp' ) );
		$nonce    = wp_create_nonce( 'wp_rest' );
		?>
		<div class="wrap" id="aime-whatsapp-page">
			<h1><?php esc_html_e( 'WhatsApp', 'ai-marketing-expert' ); ?></h1>
			<p><?php esc_html_e( 'Link a WhatsApp number to let the AI chatbot answer incoming WhatsApp messages automatically.', 'ai-marketing-expert' ); ?></p>

			<div class="card" style="max-width:480px;padding:20px;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'Connection', 'ai-marketing-expert' ); ?></h2>
				<p id="aime-wa-status"><?php esc_html_e( 'Checking status…', 'ai-marketing-expert' ); ?></p>
				<div id="aime-wa-qr" style="margin:16px 0;"></div>
				<p>
					<button type="button" class="button button-primary" id="aime-wa-connect"><?php esc_html_e( 'Connect / Show QR code', 'ai-marketing-expert' ); ?></button>
					<button type="button" class="button" id="aime-wa-logout" style="display:none;"><?php esc_html_e( 'Disconnect', 'ai-marketing-expert' ); ?></button>
				</p>
				<p class="description"><?php esc_html_e( 'Open WhatsApp on your phone → Linked Devices → Link a Device, then scan the QR code above.', 'ai-marketing-expert' ); ?></p>
			</div>

			<div class="card" style="max-width:480px;padding:20px;margin-top:16px;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'Chatbot', 'ai-marketing-expert' ); ?></h2>
				<?php if ( empty( $bots ) ) : ?>
					<p><?php esc_html_e( 'Create a chatbot first — WhatsApp messages are answered by one of your existing bots.', 'ai-marketing-expert' ); ?></p>
				<?php else : ?>
					<p>
						<label for="aime-wa-bot"><?php esc_html_e( 'Bot that answers WhatsApp messages:', 'ai-marketing-expert' ); ?></label><br />
						<select id="aime-wa-bot">
							<?php foreach ( $bots as $bot ) : ?>
								<option value="<?php echo esc_attr( $bot->id ); ?>"><?php echo esc_html( $bot->name ); ?></option>
							<?php endforeach; ?>
						</select>
						<button type="button" class="button" id="aime-wa-save-bot"><?php esc_html_e( 'Save', 'ai-marketing-expert' ); ?></button>
					</p>
					<p class="description" id="aime-wa-bot-saved" style="display:none;color:#1a7f37;"><?php esc_html_e( 'Saved.', 'ai-marketing-expert' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<script>
		(function () {
			var restUrl = <?php echo wp_json_encode( $rest_url ); ?>;
			var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
			var poll    = null;

			function apiFetch( path, options ) {
				options = options || {};
				options.headers = Object.assign( {}, options.headers, { 'X-WP-Nonce': nonce, 'Content-Type': 'application/json' } );
				return fetch( restUrl + path, options ).then( function ( r ) { return r.json(); } );
			}

			function renderStatus( data ) {
				var statusEl  = document.getElementById( 'aime-wa-status' );
				var qrEl      = document.getElementById( 'aime-wa-qr' );
				var logoutBtn = document.getElementById( 'aime-wa-logout' );

				if ( data.status === 'connected' ) {
					statusEl.textContent = 'Connected' + ( data.phone ? ' (+' + data.phone + ')' : '' ) + '.';
					qrEl.innerHTML = '';
					logoutBtn.style.display = 'inline-block';
					if ( poll ) { clearInterval( poll ); poll = null; }
				} else if ( data.status === 'qr' ) {
					statusEl.textContent = 'Scan this QR code from WhatsApp on your phone:';
					logoutBtn.style.display = 'none';
				} else if ( data.status === 'connecting' ) {
					statusEl.textContent = 'Connecting…';
					logoutBtn.style.display = 'none';
				} else if ( data.status === 'unreachable' ) {
					statusEl.textContent = 'WhatsApp bridge is not running.';
					logoutBtn.style.display = 'none';
				} else {
					statusEl.textContent = 'Not connected.';
					logoutBtn.style.display = 'none';
				}
			}

			function refreshQr() {
				apiFetch( '/qr' ).then( function ( data ) {
					renderStatus( data );
					var qrEl = document.getElementById( 'aime-wa-qr' );
					if ( data.qr ) {
						qrEl.innerHTML = '<img src="' + data.qr + '" alt="QR code" style="width:220px;height:220px;" />';
					} else if ( data.status !== 'connected' ) {
						qrEl.innerHTML = '';
					}
				} );
			}

			document.getElementById( 'aime-wa-connect' ).addEventListener( 'click', function () {
				apiFetch( '/connect', { method: 'POST' } ).then( function () {
					refreshQr();
					if ( ! poll ) {
						poll = setInterval( refreshQr, 3000 );
					}
				} );
			} );

			document.getElementById( 'aime-wa-logout' ).addEventListener( 'click', function () {
				apiFetch( '/logout', { method: 'POST' } ).then( function ( data ) {
					renderStatus( data );
				} );
			} );

			var saveBotBtn = document.getElementById( 'aime-wa-save-bot' );
			if ( saveBotBtn ) {
				saveBotBtn.addEventListener( 'click', function () {
					var botId = document.getElementById( 'aime-wa-bot' ).value;
					apiFetch( '/settings', { method: 'POST', body: JSON.stringify( { bot_id: parseInt( botId, 10 ) } ) } ).then( function () {
						var saved = document.getElementById( 'aime-wa-bot-saved' );
						saved.style.display = 'block';
						setTimeout( function () { saved.style.display = 'none'; }, 2000 );
					} );
				} );
			}

			apiFetch( '/settings' ).then( function ( data ) {
				var select = document.getElementById( 'aime-wa-bot' );
				if ( select && data.bot_id ) {
					select.value = String( data.bot_id );
				}
			} );

			refreshQr();
			poll = setInterval( refreshQr, 3000 );
		})();
		</script>
		<?php
	}
}
